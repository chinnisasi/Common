//
//  MMTWebServiceConstants.h
//  MakeMyTrip
//
//  Created by Indra Mohan on 19/02/14.
//  Copyright (c) 2014 MakeMyTrip India Pvt. Ltd. All rights reserved.
//

#import "CommonHeaders.h"
#import <Foundation/Foundation.h>

//typedef NS_ENUM(NSInteger, WebServiceRequestType) {
//    eFetchPaymentOptions = 23,
//    eNetworkReliabilityCheck,
//    eCardBinProperty,
//    eSubmitPayment,
//    eZipDialSubmitRequest,
//    eConfirmBooking,
//    eZipDialStatus,
//    eSaveBookingHotel,
//    eDOMFlightHotelCrossSell,
//    eDownloadImage,
//    eRefundFailedBookingToWallet,
//    eFetchBookingStatus,
//};

#define MMTWebServiceErrorDomain @"MMTWebServiceErrorDomain"
#define HTTPRequestOperationFailingURLResponseErrorKey @"HTTPRequestOperationFailingURLResponseErrorKey"

@interface MMTWebServiceConstants : NSObject

@end
