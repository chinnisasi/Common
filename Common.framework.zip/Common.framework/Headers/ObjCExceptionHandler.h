//
//  ObjCExceptionHandler.h
//  MakeMyTrip
//
//  Created by Pranali Jain on 15/02/19.
//  Copyright © 2019 MakeMyTrip India Pvt. Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface ObjCExceptionHandler : NSObject

+ (BOOL)catchException:(void(^)())tryBlock error:(__autoreleasing NSError **)error;

@end

NS_ASSUME_NONNULL_END
