//
//  MMTLocationManager.h
//  MMT_IphoneApp
//
//  Created by makemytrip on 15/01/15.
//
//

#import <Foundation/Foundation.h>
#import <CoreLocation/CoreLocation.h>

@interface MMTLocationManager : NSObject<CLLocationManagerDelegate>

@property(nonatomic, strong)CLLocationManager *plocationManager;
@property(nonatomic, strong)CLLocation *pcurrentlocation;
@property(nonatomic, strong)NSTimer *timer;
@property(nonatomic)Boolean isForcedStart;
@property (weak, nonatomic) id delegate;

/*!
 This is singleton class so to Prevent a call to init we are decalre this followed by unavailable() attribute
 */
-(id)init  __attribute__((unavailable()));


/*!
 This class method is used to return the singleton object
 */
+ (MMTLocationManager *)sharedManager;


/*!
 This class method is used to check two conditions with locationmanger first is locationserviceavailable
 and second is app autorized to provide to location. and also shows alert in any negetive condition.
 */
+ (BOOL)isAvailableAndAuthorized;

//
+ (BOOL)isLocationAvailableWithoutAlert;

/*!
 This class method is used to start updationservices and even contains refrence to class which implements the protocol defined above in case no use pass nil.
 */
+(void)start;
+(void)forceStart;
/*!
 This class method is used to stop updationservices.
 */
+(void)stop;

+(void)requestAlwaysAuth;

+(NSDictionary *)userCurrentLocation;

@end
