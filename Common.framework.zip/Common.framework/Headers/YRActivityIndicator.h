//
//  YRActivityIndicator.h
//  MakeMyTrip
//
//  Created by Stefan Ceriu on 12/01/2014.
//  Copyright (c) 2014 Stefan Ceriu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YRActivityIndicator : UIActivityIndicatorView

+ (void)showActivityIndicatorInView:(UIView *)view;
+ (void)showActivityIndicatorInView:(UIView *)view center:(CGPoint)center;
+ (void)showWhiteActivityIndicatorInView:(UIView *)view;

+ (void)hideActivityIndicatorInView:(UIView *)view;

@end
