//
//  UIBarButtonItem+MMTBarButtonItem.h
//  MakeMyTrip
//
//  Created by Puneet Sharma on 13/08/15.
//  Copyright (c) 2015 MakeMyTrip India Pvt. Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIBarButtonItem (MMTBarButtonItem)

+ (instancetype)mmt_AppearanceWhenContainedIn:(Class<UIAppearanceContainer>)containerClass;

@end
