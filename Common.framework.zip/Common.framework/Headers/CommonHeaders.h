//
//  CommonHeaders.h
//  MakeMyTrip
//
//  Created by makemytrip on 10/07/15.
//  Copyright (c) 2015 MakeMyTrip India Pvt. Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>

// Keys for Notifications..

#define KEY_NOTIF_SEARCHED_SUCCESS @"AirPortListLoadedSuccessfully"
#define KEY_NOTIF_SEARCHED_FAILED  @"AirPortListLoadingFailed"

//**********Offline Vouchers Url*******************//
#define MissingFlightPNRsURL @"https://connect.makemytrip.com/makemytrip/ws3.0/rest/flight/MyTripHandler/getOfflineVouchers"
#define GetMyTripsURL @"https://support.makemytrip.com/MMT_WEBS_ItineraryInfoDetails_Api/api/ItineraryInfoDetails/GetMyTrips"
#define ModifyBookingURL @"https://support.makemytrip.com/MyAccount/DateChange/DateChangeListing?hdnBookingID=%@&hdnPhoneNumber=%@&NativeAppidentifier=true"
#define HotelCancellationURL @"https://support.makemytrip.com/MTBHotelBookingCancellation.aspx?hdnBookingID=%@&hdnPhoneNumber=%@&NativeAppidentifier=true"
#define FlightsCancellationURL @"https://support.makemytrip.com/DomCancellation.aspx?hdnBookingID=%@&hdnPhoneNumber=%@&NativeAppidentifier=true"
#define RefundTrackerURL @"https://support.makemytrip.com/Refund_Multiple.aspx?hdnBookingID=%@&hdnPhoneNumber=%@&NativeAppidentifier=true"

#define HOTEL_CANCELLATION_NEW_REDIRECT @"https://support.makemytrip.com/MTBHotelBookingCancellationNew.aspx"
#define HOTEL_CANCELLATION_CONFIRMATION_REDIRECT @"https://support.makemytrip.com/MTBHotelBookingCancellationConfirmation.aspx"


#define LODING_INDICATOR_LABEL_ONE      @"Loding indicator label one"
#define LODING_INDICATOR_LABEL_TWO      @"Loding indicator label two"
#define LODING_INDICATOR_LABEL_THREE    @"Loding indicator label three"
#define LODING_INDICATOR_LABEL_FOUR     @"Loding indicator label four"
#define LODING_INTERSTIAL               @"InterstialType"
#define LOCATION_ERROR                  @"LOCATION NOT FOUND ERROR"
#define kNotiNearByLocationFetched      @"NearByLocationFetched"
#define NSSTRING_HAS_DATA(_x) ( ((_x) != nil) && ( [(_x) length] > 0 ) )


//////
#define ReachabilityManager                 [MMTReachabilityManager sharedManager]
#define ScreenSize                          [UIScreen mainScreen].bounds.size
//#define MMT_REACHABILITY_ERROR_MESSAGE      @"There is no Network Connection. Please check your Network Settings."
#define MMT_REACHABILITY_ERROR_HEADER       NSLocalizedString(@"PAY_OPTION_ERROR_TITLE", nil)
#define MMT_REACHABILITY_ERROR_MESSAGE      NSLocalizedString(@"REACHABILITY_ERROR_MESSAGE",nil)
#define MMT_LOCATION_ERROR_MESSAGE          NSLocalizedString(@"WE_COULD_NOT_DETECT_YOUR_CURRENT_LOCATION_PLEASE_SELECT_CITY_MANUALLY", nil)
#define MMT_TIMEOUT_ERROR_HEADER            NSLocalizedString(@"Network_Timed_Out",nil)
#define MMT_TIMEOUT_ERROR_MESSAGE           NSLocalizedString(@"OOPS_WE_ARE_FACING_SOME_TECHNICAL_GLITCH_PLEASE_TRY_LATER",nil)
#define MMT_SERVER_ERROR_HEADER             NSLocalizedString(@"PAY_OPTION_ERROR_TITLE", nil)
#define MMT_SERVER_BAD_URL                  NSLocalizedString(@"BAD_URL_ERROR", nil)
#define MMT_NETWORK_ERROR                   NSLocalizedString(@"OOPS_WE_ARE_FACING_SOME_TECHNICAL_GLITCH_PLEASE_TRY_LATER",nil)

#define Base_URL_Book_Flight                @"connect.makemytrip.com"
#define Base_URL_Book_Flight_RB_CREATE_USER @"connect.makemytrip.com"
#define base_url_testing                    @"https://connect.makemytrip.com/makemytrip/ws3.0/rest/flight/"
#define BB_MOBILE_WS_URL                    @"bb.makemytrip.com"

#define MMT_FORGOT_PASSWOR_URL      [NSString stringWithFormat:@"%@%@",base_url_testing,@"user/forgotPassword"]
#define MMT_REGISTER_USER_URL       [NSString stringWithFormat:@"%@%@",base_url_testing,@"user/register"]
#define MMT_LOGIN_URL               [NSString stringWithFormat:@"%@%@",base_url_testing,@"user/login"]
#define MMT_FB_LOGIN_URL            [NSString stringWithFormat:@"%@%@",base_url_testing,@"user/connectUser"]
#define MMT_BB_LOGIN_URL            @"https://bb.makemytrip.com/apps-services/UserAuthentication"
#define MMT_FLIGHT_STATUS_URL       [NSString stringWithFormat:@"https://%@%@",BB_MOBILE_WS_URL,@"/apps-services/FlightStatusHandler"]
#define MMT_NEARBYLOCATION_URL      @"https://apps.makemytrip.com/solr/select/"
#define BASE_URL_VALIDATE_ECOUPON   @"https://flights.makemytrip.com/makemytrip/validateEcoupon"


#define MMT_BOOK_LATER_URL      [NSString stringWithFormat:@"%@%@",base_url_testing,@"user/bookLater"]

#define kApplicationName        @"MakeMyTrip"

#define GrayBorderColor         [UIColor colorWithWhite:0.5 alpha:0.3].CGColor
#define kViewBackgroundColor [UIColor colorWithRed:229.0/255.0 green:229.0/255.0 blue:229.0/255.0 alpha:1]
#define kContainerViewBorderColor [UIColor colorWithRed:212.0/255.0 green:212.0/255.0 blue:212.0/255.0 alpha:1]
#define kContainerViewBackgroundColor [UIColor whiteColor]

#define kYellowStripTag 3456
//#define MMT_UPComingTrips_Method  @"upComingTrips"
#define kContentType @"application/json"
//#define PASSBOOK_WS_URL @"https://connect.makemytrip.com/Passbook/createPass"
#define PASSBOOK_WS_URL         @"https://supportz.makemytrip.com/api/createPass"
#define PASS_TYPE_IDENTIFIER    @"pass.mmt.flightpass"

#define kContainerViewCornerRadius 3.0
#define kContainerViewBorderWidth  1.0/[[UIScreen mainScreen] scale]
#define kContentLeftPadding        10.0
#define kContentRightPadding       10.0
#define kPaddingBetweenContainers  6.0
#define kContainerHeight           44
#define kProgressBarHeight         15
@interface CommonHeaders : NSObject


@end
