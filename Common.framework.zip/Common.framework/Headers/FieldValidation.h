//
//  FieldValidation.h
//  MMT_IphoneApp
//
//  Created by Divum Corporate Services Pvt Ltd on 24/03/14.
//
//

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSInteger, PaxType) {
    Adult,
    Child,
    Infant,
    ChildWithBed,
    ChildWithoutBed
};

typedef NS_ENUM(NSInteger, PassengerType) {
    Domestic,
    International
};




typedef NS_ENUM(NSInteger, FormType) {
    Add,
    Edit,
    Select,
    InitialAdd
} ;

typedef NS_ENUM(NSInteger, TravellerPageType) {
    EmptyTraveller,
    AddedTraveller
    
};

@interface FieldValidation : NSObject

+(NSString*)isFirstNameValid:(NSString*)firstName;
+(NSString*)isLastNameValid:(NSString*)lastName isDomestic:(BOOL)isDomestic isFlight:(BOOL)isFlight;
+(NSString*)isLastNameValid:(NSString*)lastName;
+(NSString*)isFullNameValid:(NSString *)firstName lastname:(NSString*)lastName;
+(NSString *)removesUnwantedSpacesFromStartAndEnd:(NSString *)oldString;
+(BOOL)isOnlyAlphabetAndSpace:(NSString *)name;
+(NSString *)isEmailValid:(NSString*)email;
+(NSString *)isPhoneNumberValid:(NSString*)phoneNumber countryCode:(NSString*)countryCode;
+(NSString *)isFlightPhoneNumberValid:(NSString*)phoneNumber countryCode:(NSString*)countryCode;
+(NSString *)isDOBValid:(NSDate*)dateOfBirth departureDate:(NSDate *)departureDate travellerType:(PaxType)travellerType minimumAge:(NSInteger)minAge maximumAge:(NSInteger)maxAge;
+(NSString *)isDOBValid:(NSDate*)dateOfBirth departureDate:(NSDate *)departureDate travellerType:(PaxType)travellerType;
+(NSString *)isPassportNumberValid:(NSString*)passportNumber;
+(NSString *)isPassportExpiryDateValid:(NSDate*)passportExpiryDate departureDate:(NSDate *)departureDate;


+ (NSInteger)GetAgeFrom:(NSDate *)dateOfBirth;
+ (NSInteger)GetAgeFrom:(NSDate *)dateOfBirth onDate:(NSDate *)date;

+(NSString *)isMealOptionValid:(NSString*)meal;
+(NSString *)isCountryValid:(NSString*)country;
+(NSString *)isNationalityValid:(NSString*)nationality;
+(NSString *)isAgeValid:(NSInteger)Age travellerType:(PaxType)travellerType;
+(NSString *)isAgeValid:(NSInteger)Age travellerType:(PaxType)travellerType minimumAge:(NSInteger)minAge maximumAge:(NSInteger)maxAge;

+(NSString *)isGSTNumberValid:(NSString*)gstNumber;
+(NSString *)isCompanyNameValid:(NSString*)companyName;
+(NSString *)isCompanyAddressValid:(NSString*)companyAddress;

@end
