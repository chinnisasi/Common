//
//  UDCryptoManager.h
//  MakeMyTrip
//
//  Created by Pranali Jain on 22/02/19.
//  Copyright © 2019 MakeMyTrip India Pvt. Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface UDCryptoManager : NSObject

- (NSString*)populateTrust:(NSDictionary *)salt token:(NSString *)token;
- (NSString*)populateHMAC:(NSString*)app_id mobile:(NSString*)mobile token:(NSString*)token deviceId:(NSString*)deviceId;
- (NSString*)generate:(NSString *)message token:(NSString *)token;
- (NSString*)sha256:(NSString *)key;
- (NSData *)encrypt:(NSData *)plainText key:(NSString *)key iv:(NSString *)iv;

@end

NS_ASSUME_NONNULL_END
